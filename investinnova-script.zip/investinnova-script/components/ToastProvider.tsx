"use client";
import { Toaster } from "react-hot-toast";

import React from "react";

const ToastProvider = () => {
  return <Toaster />;
};

export default ToastProvider;
