"use client";

import React from "react";

const BankTranfer = () => {
  return <div>Bank Tranfer</div>;
};

export default BankTranfer;
