import Login from "@/components/auth/Login";
import React from "react";

const index = () => {
  return <Login />;
};

export default index;
