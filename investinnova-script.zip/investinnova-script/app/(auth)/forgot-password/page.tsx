import ForgotPassword from "@/components/auth/ForgotPassword";
import React from "react";

const page = () => {
  return <ForgotPassword />;
};

export default page;
