import NewPassword from "@/components/auth/NewPassword";
import React from "react";

const newpassword = () => {
  return <NewPassword />;
};

export default newpassword;
