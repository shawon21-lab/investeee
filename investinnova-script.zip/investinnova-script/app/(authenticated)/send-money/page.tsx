import Send from "@/components/authenticated/send-money";
import React from "react";

const Page = () => {
  return <Send />;
};

export default Page;
