import Card from "@/components/authenticated/card";
import React from "react";

const page = () => {
  return <Card />;
};

export default page;
